<?php
/*
Plugin Name: Beachcomber booking widget
Description: This Beachcomber plugin with a floating widget, results page, and admin configuration & storage.
Version: 1.6.4
Author: Beachcomber Tours
*/


include_once 'admin/bb-admin.php';
include_once 'results/bb-results.php';
include_once 'results/bb-specials.php';

// // Enqueue the necessary scripts and styles for the widget.
function beachcomber_booking_enqueue_scripts() {

$plugin_version = '1.6.4';

wp_enqueue_style(
  'beachcomber_booking-style',
  plugin_dir_url(__FILE__) . 'css/beachcomber_booking-style.css',
  [],
  $plugin_version
);

wp_enqueue_script(
  'beachcomber_booking-script',
  plugin_dir_url(__FILE__) . 'js/beachcomber_booking-script.js',
  ['jquery'],
  $plugin_version,
  true
);


  // Pass AJAX URL to JavaScript
  wp_localize_script('beachcomber_booking-script', 'beachcomberBookingScript', [
    'ajax_url' => admin_url('admin-ajax.php'),
    'getrates_url' => admin_url('admin-ajax.php') . '?action=beachcomber_get_rates',
    'getbooking_url' => admin_url('admin-ajax.php') . '?action=beachcomber_get_quote',
    'sendQuote_url' => admin_url('admin-ajax.php') . '?action=beachcomber_send_quote_ajax',
    'showFilters' => get_option('beachcomber_booking_show_filters') ? true : false,
  ]);
}
add_action('wp_enqueue_scripts', 'beachcomber_booking_enqueue_scripts', 50);


add_action('wp_enqueue_scripts', function() {
  $showFilters = get_option('beachcomber_booking_show_filters') ? 'true' : 'false';
  $inline_js = "
    document.addEventListener('DOMContentLoaded', function() {
      const showFilters = $showFilters;
      const filtersContainer = document.getElementById('filters');
        if (filtersContainer) {
    if (showFilters) {
      filtersContainer.style.visibility = 'visible'; // Make it visible
      filtersContainer.style.opacity = 1; // Ensure it's not hidden in terms of opacity
    } else {
      filtersContainer.style.visibility = 'hidden'; // Hide it, but keep the space
      filtersContainer.style.opacity = 0; // Optional: Hide using opacity
    }
  }
    });
  ";
  wp_add_inline_script('beachcomber_booking-script', $inline_js);
}, 60);

function beachcomber_booking_handle_email() {
  // Verify nonce
  if (!isset($_POST['send_ajax_email_nonce']) || !wp_verify_nonce($_POST['send_ajax_email_nonce'], 'send_ajax_email_action')) {
    wp_send_json_error(['message' => 'Invalid security token. Please refresh the page and try again.']);
  }

  // Check required fields
  $firstName = isset($_POST['firstName']) ? sanitize_text_field($_POST['firstName']) : '';
  $lastName = isset($_POST['lastName']) ? sanitize_text_field($_POST['lastName']) : '';
  $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
  $mobile = isset($_POST['mobile']) ? sanitize_text_field($_POST['mobile']) : '';
  $noAdults = isset($_POST['noAdults']) ? sanitize_text_field($_POST['noAdults']) : '';
  $travelDate = isset($_POST['travelDate']) ? sanitize_text_field($_POST['travelDate']) : '';
  $noChildren = isset($_POST['noChildren']) ? sanitize_text_field($_POST['noChildren']) : '';
  $childAges = isset($_POST['childAges']) ? sanitize_text_field($_POST['childAges']) : '';
  $noInfants = isset($_POST['noInfants']) ? sanitize_text_field($_POST['noInfants']) : '';
  $depDest = isset($_POST['depDest']) ? sanitize_text_field($_POST['depDest']) : '';
  $hotelName = isset($_POST['hotelName']) ? sanitize_text_field($_POST['hotelName']) : '';
  $packageOptions = isset($_POST['packageOptions']) ? sanitize_text_field($_POST['packageOptions']) : '';
  $stayLength = isset($_POST['stayLength']) ? sanitize_text_field($_POST['stayLength']) : '';
  $budget = isset($_POST['budget']) ? sanitize_text_field($_POST['budget']) : '';
  $details = isset($_POST['details']) ? sanitize_textarea_field($_POST['details']) : '';
  $accSpecial1 = isset($_POST['accSpecial1']) ? sanitize_text_field($_POST['accSpecial1']) : '';
  $honeymoonRate = isset($_POST['honeymoonRate']) ? sanitize_text_field($_POST['honeymoonRate']) : '';

  if (empty($firstName) || empty($lastName) || empty($email) || empty($mobile) || empty($travelDate)) {
    wp_send_json_error(['message' => 'Personal information and the travel date are required.']);
  }

  // Prepare email
  $to = esc_attr(get_option('beachcomber_booking_enquiries')); // Send to email
  $subject = "New Contact Form Submission from $firstName $lastName";
  $body = "Full Name: $firstName $lastName\nEmail: $email\nMobile: $mobile\nNo Adults: $noAdults\nTravel Date: $travelDate\nNo Children: $noChildren\nChild Ages: $childAges\nNo Infants: $noInfants\nDeparture Destination: $depDest\nHotel Name:$hotelName\nPackage Options: $packageOptions\nStay Length: $stayLength\nBudget: $budget\nHoneymoon rate: $honeymoonRate\nSpecial Offers: $accSpecial1\nDetails:\n$details";
  $headers = ['Content-Type: text/plain; charset=UTF-8', "Reply-To: $email"];

  // Send email
  if (wp_mail($to, $subject, $body, $headers)) {
    wp_send_json_success(['message' => 'Email sent successfully!']);
  } else {
    wp_send_json_error(['message' => 'Failed to send email. Please try again later.']);
  }
}
add_action('wp_ajax_send_ajax_email', 'beachcomber_booking_handle_email');
add_action('wp_ajax_nopriv_send_ajax_email', 'beachcomber_booking_handle_email');

// Create the floating widget HTML.
function beachcomber_booking_floating_widget(){
  // Check if widget is enabled globally
  if (esc_attr(get_option('beachcomber_booking_show_widget')) !== "1") {
    return;
  }

  // Check if we're on a page, and whether this page is allowed
  if (is_page()) {
    $current_page_id = get_queried_object_id();
    $allowed_pages = get_option('beachcomber_booking_widget_pages', []);

    // Only proceed if this page is in the allowed list
    if (!in_array($current_page_id, (array) $allowed_pages)) {
      return;
    }
  }

  // If not a page (e.g. a post or archive), don't show the widget
  else {
    return;
  }


  $minDay = new DateTime();
  $minDay->modify('+7 day');

  $maxDay = new DateTime();
  $maxDay->modify('+350 day');

  $tomorrow = new DateTime();
  $tomorrow->modify('+7 day');

  $nextday = new DateTime();
  $nextday->modify('+10 day');

  $maxDate = date('Y-m-d');
  $minDate = date('Y-m-d', strtotime('-2 years'));

  ?>
  <input type="checkbox" id="beachcomber_booking-toggle-widget">
  <div id="beachcomber_booking-floating-widget">
    <label for="beachcomber_booking-toggle-widget">+</label>
    <h3>Quote Now</h3>
    <div id="beachcomber_booking-searchWidget">
      <div>
        <label for="hotelCode">Beachcomber Mauritius:</label>
        <select name="hotelCode" id="hotelCode">
          <option value="">-- Select your hotel --</option>
          <option value="CAN">Canonnier Beachcomber - 4 star</option>
          <option value="MAU">Mauricia Beachcomber - 4 star</option>
          <option value="VIC">Victoria Beachcomber - 4 star superior</option>
          <option value="SHA">Shandrani Beachcomber - 4 star superior</option>
          <option value="TAB">Trou aux Biches Beachcomber - 5 star</option>
          <option value="PAR">Paradis Beachcomber - 5 star</option>
          <option value="DIN">Dinarobin Beachcomber - 5 star</option>
          <option value="RP">Royal Beachcomber - 5 star luxury</option>
        </select>
      </div>
      <div>
        <label for="beachcomber_booking-guests">Guests:</label>
        <input type="number" id="beachcomber_booking-guests" name="nbrAdults" min="1" max="6" value="2" required>
      </div>
      <div>
        <label for="beachcomber_booking-check-in">Departure Date:</label>
        <input
          type="date"
          name="dateDeparture"
          id="dateDeparture"
          value="<?=$tomorrow->format('Y-m-d');?>"
          min="<?=$minDay->format('Y-m-d');?>"
          max="<?=$maxDay->format('Y-m-d');?>"
        >
      </div>
      <div>
        <label for="beachcomber_booking-check-out">Return Date:</label>
        <input
          type="date"
          name="dateReturn"
          id="dateReturn"
          value="<?=$nextday->format('Y-m-d');?>"
          min="<?=$minDay->format('Y-m-d');?>"
          max="<?=$maxDay->format('Y-m-d');?>"
        >
      </div>
      <input id="submitWidgetForm" type="submit" value="Search">
    </div>
  </div>
  <?php
}
add_action('wp_footer', 'beachcomber_booking_floating_widget');


// === Create the "Beachcomber Search Results" page ===
function beachcomber_booking_create_results_page() {
    $old_slug = 'bookings-results';
    $old_title = 'Bookings Results';
    $new_title = 'Beachcomber Search Results';
    $new_slug = 'beachcomber-search-results';
    $shortcode = '[beachcomber_search_results]';

    beachcomber_create_or_update_page($old_slug, $old_title, $new_title, $new_slug, $shortcode);
}
// register_activation_hook(__FILE__, 'beachcomber_booking_create_results_page');

// === Create the "Beachcomber Specials" page ===
function beachcomber_booking_create_specials_page() {
    $old_slug = 'holiday-specials';
    $old_title = 'Holiday Specials';
    $new_title = 'Beachcomber Specials';
    $new_slug = 'beachcomber-specials';
    $shortcode = '[beachcomber_holiday_specials]';

    beachcomber_create_or_update_page($old_slug, $old_title, $new_title, $new_slug, $shortcode);
}
// register_activation_hook(__FILE__, 'beachcomber_booking_create_specials_page');

// === Helper: Create or update page ===
function beachcomber_create_or_update_page($old_slug, $old_title, $new_title, $new_slug, $shortcode) {
    // Check if new page already exists by slug
    $existing_page = get_page_by_path($new_slug);
    if ($existing_page) {

        return; // Page already exists, skip
    }

    // Check if old page exists by slug or title
    $old_page = get_page_by_path($old_slug) ?: get_page_by_title($old_title);

    if ($old_page) {
        // Rename old page to new
        wp_update_post([
            'ID'           => $old_page->ID,
            'post_title'   => $new_title,
            'post_name'    => $new_slug,
            'post_content' => $shortcode,
        ]);
    } else {
        // Create new page
        wp_insert_post([
            'post_title'   => $new_title,
            'post_name'    => $new_slug,
            'post_content' => $shortcode,
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ]);
    }
}

// Activation hook: reset admin custom settings + pages to fix caching issue
function beachcomber_booking_activate() {
  if (get_option('beachcomber_booking_show_filters') === false) {
    update_option('beachcomber_booking_show_filters', 1);
  }
  if (get_option('beachcomber_booking_show_widget') === false) {
    update_option('beachcomber_booking_show_widget', 1);
  }
  beachcomber_booking_create_results_page();
  beachcomber_booking_create_specials_page();
  if (function_exists('wp_cache_flush')) {
    wp_cache_flush();
  }
}
register_activation_hook(__FILE__, 'beachcomber_booking_activate');


// Handle AJAX request for rates data
function beachcomber_get_rates_ajax() {
  // Set proper headers
  header("Content-Type: application/json");
  $filepath = __DIR__ . "/js/rates-data.json";
  
  // previous js/rates-data.json file exists
  if (file_exists($filepath)) {
    // check for the latest data "lastRatesUpdate"
    $json = file_get_contents($filepath);
    $data = json_decode($json, true);

    // Y PHP Y?
    $lastRatesUpdate = $data['lastRatesUpdate'];

    // check if lastRatesUpdate is found in $json
    if (isset($lastRatesUpdate)) {
      $currentDate = date('Y-m-d');

      substr($lastRatesUpdate, 0, 10) === $currentDate;

      // check if current date is older than lastRatesUpdate
      if (substr($lastRatesUpdate, 0, 10) === $currentDate) {
        echo $json;
        exit;
      }  
    }
  }



  // Get API key from WordPress options
  $api_key = get_option('beachcomber_booking_api_key');
  
  // Initialize cURL
  $ch = curl_init();
  
  // Configure cURL options
  curl_setopt($ch, CURLOPT_URL, "https://api.beachcomberonline.co.za/getrates");
  curl_setopt($ch, CURLOPT_HTTPHEADER, [
      "Content-Type: application/json",
      "BeachcomberKey: " . $api_key
  ]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  
  // Execute the request and capture the response
  $response = curl_exec($ch);
  $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  
  // Handle cURL errors
  if ($response === false) {
      wp_send_json_error([
          "error" => "Error connecting to the API",
          "details" => curl_error($ch)
      ]);
  } else {
      // Cache the response
      // update_option('beachcomber_rates_cache', $response);
      // update_option('beachcomber_rates_last_update', date('Y-m-d'));
      
      // Return the API response
      file_put_contents($filepath, $response);      
      echo $response;
  }
  
  // Close cURL
  curl_close($ch);
  
  // Always exit after handling AJAX
  wp_die();
}

// Register AJAX actions for both logged-in and non-logged-in users
add_action('wp_ajax_beachcomber_get_rates', 'beachcomber_get_rates_ajax');
add_action('wp_ajax_nopriv_beachcomber_get_rates', 'beachcomber_get_rates_ajax');

// Handle AJAX request for rates data
function beachcomber_get_quote_ajax() {
  // Set proper headers
  header("Content-Type: application/json");

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read the input JSON payload
    $inputData = file_get_contents("php://input");

    // Get API key from WordPress options
    $api_key = get_option('beachcomber_booking_api_key');
    
    // Initialize cURL
    $ch = curl_init();
    
    // Configure cURL options
    curl_setopt($ch, CURLOPT_URL, "https://api.beachcomberonline.co.za/getquote");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $inputData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
      "Content-Type: application/json",
      "BeachcomberKey: " . $api_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    // Execute the request and capture the response
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    // Handle cURL errors
    if ($response === false) {
      wp_send_json_error([
        "error" => "Error connecting to the API",
        "details" => curl_error($ch)
      ]);
    } else {
      http_response_code($httpCode);
      echo $response;
    }
    
    // Close cURL
    curl_close($ch);
    
    // Always exit after handling AJAX
    wp_die();
  }
}

function beachcomber_send_quote_ajax() {
  // Set JSON header
  header("Content-Type: application/json");

  // Only allow POST
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input JSON
    $inputData = file_get_contents("php://input");

    // Get API key from WordPress options
    $api_key = get_option('beachcomber_booking_api_key');

    // Optional: Get user token from somewhere if needed
    // $user_token = get_user_meta(get_current_user_id(), 'beachcomber_token', true);

    // Setup cURL
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, "https://api.beachcomberonline.co.za/sendQuote");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $inputData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
      "Content-Type: application/json",
      "BeachcomberKey: " . $api_key,
      // Optional token header if needed
      // "BeachcomberToken: " . $user_token,
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if ($response === false) {
      wp_send_json_error([
        "error" => "Error sending quote request",
        "details" => curl_error($ch)
      ]);
    } else {
      http_response_code($httpCode);
      echo $response;
    }

    curl_close($ch);
    wp_die();
  }
}


add_action('wp_ajax_beachcomber_get_quote', 'beachcomber_get_quote_ajax');
add_action('wp_ajax_nopriv_beachcomber_get_quote', 'beachcomber_get_quote_ajax');

add_action('wp_ajax_beachcomber_send_quote_ajax', 'beachcomber_send_quote_ajax');
add_action('wp_ajax_nopriv_beachcomber_send_quote_ajax', 'beachcomber_send_quote_ajax');