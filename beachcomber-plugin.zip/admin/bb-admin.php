<?php
/*****************************************
* Register settings, section, and field.
******************************************/

function beachcomber_booking_register_settings() {
  register_setting('beachcomber_booking_options', 'beachcomber_booking_api_key');
  register_setting('beachcomber_booking_options', 'beachcomber_booking_enquiries');
  register_setting('beachcomber_booking_options', 'beachcomber_booking_show_widget');
  register_setting('beachcomber_booking_options', 'beachcomber_booking_show_filters');
  register_setting('beachcomber_booking_options', 'beachcomber_booking_pclr');
  register_setting('beachcomber_booking_options', 'beachcomber_booking_sclr');
  register_setting('beachcomber_booking_options', 'beachcomber_booking_bclr');
  register_setting('beachcomber_booking_options', 'beachcomber_booking_widget_pages');

}
add_action('admin_init', 'beachcomber_booking_register_settings');

function beachcomber_booking_settings_page() {
  add_options_page(
      'Beachcomber API/Widget Settings',
      'Beachcomber API',
      'manage_options',
      'beachcomber_booking-settings',
      'beachcomber_booking_settings_page_html'
  );
}
add_action('admin_menu', 'beachcomber_booking_settings_page');

function beachcomber_booking_settings_page_html() {
  if (!current_user_can('manage_options')) {
    return;
  }
  ?>
  <div class="wrap">
      <h1>Floating Widget Settings</h1>
      <form action="options.php" method="post">
          <?php
          settings_fields('beachcomber_booking_options');
          do_settings_sections('beachcomber_booking_options');
          ?>
          <table class="form-table">
              <tr valign="top">
                <th scope="row">API Key</th>
                <td><input type="text" name="beachcomber_booking_api_key" value="<?php echo esc_attr(get_option('beachcomber_booking_api_key')); ?>" /></td>
              </tr>

              <tr>
                <th>Show Widget</th>
                <td>
                  <input type="checkbox" id="beachcomber_booking_show_widget" name="beachcomber_booking_show_widget" value="1" <?php checked(1, get_option('beachcomber_booking_show_widget'), true); ?> />
                  <label for="beachcomber_booking_show_widget">Show Widget</label>
                </td>
              </tr>

                    <tr>
        <th>Show Filters</th>
        <td>
          <input type="checkbox" id="beachcomber_booking_show_filters" name="beachcomber_booking_show_filters" value="1" <?php checked(1, get_option('beachcomber_booking_show_filters'), true); ?> />
          <label for="beachcomber_booking_show_filters">Show Filters on specials page</label>
        </td>
      </tr>

              <tr valign="top">
                <th scope="row">Email Enquiries</th>
                <td><input type="text" name="beachcomber_booking_enquiries" value="<?php echo esc_attr(get_option('beachcomber_booking_enquiries')); ?>" /></td>
              </tr>

<tr valign="top">
  <th scope="row">Pages to show widget</th>
  <td>
    <?php
    $pages = get_pages();
    $selected_pages = get_option('beachcomber_booking_widget_pages', []);
    ?>
    <select name="beachcomber_booking_widget_pages[]" multiple size="5" style="min-width: 300px;">
      <?php foreach ($pages as $page): ?>
        <option value="<?php echo esc_attr($page->ID); ?>" <?php selected(in_array($page->ID, (array)$selected_pages)); ?>>
          <?php echo esc_html($page->post_title); ?>
        </option>
      <?php endforeach; ?>
    </select>
    <p class="description">Hold down Ctrl (Windows) or Command (Mac) to select multiple pages.</p>
  </td>
</tr>



              <tr valign="top">
                <th scope="row">Primary colour</th>
                <td><input type="color" name="beachcomber_booking_pclr" value="<?php echo esc_attr(get_option('beachcomber_booking_pclr')); ?>" /></td>
              </tr>
              <tr valign="top">
                <th scope="row">Secondary colour</th>
                <td><input type="color" name="beachcomber_booking_sclr" value="<?php echo esc_attr(get_option('beachcomber_booking_sclr')); ?>" /></td>
              </tr>
              <tr valign="top">
                <th scope="row">Button colour</th>
                <td><input type="color" name="beachcomber_booking_bclr" value="<?php echo esc_attr(get_option('beachcomber_booking_bclr')); ?>" /></td>
              </tr>
          </table>
          <?php submit_button(); ?>
      </form>
  </div>
  <?php
}