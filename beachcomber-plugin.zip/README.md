# Beachcomber Booking Widget

A WordPress plugin that provides a comprehensive booking solution for Beachcomber Tours. The plugin includes:

- Floating booking widget for quick quote requests
- Detailed results page for displaying hotel and package information
- Holiday specials showcase page
- Admin configuration panel for API keys and display settings
- Secure integration with Beachcomber's booking API

## Features

- Real-time rate and availability checking
- Customizable widget appearance
- Responsive design for all devices
- Email inquiry system for customer follow-up
- Automatic page creation during plugin activation

## Requirements

- WordPress 5.0+
- PHP 7.2+
- Active Beachcomber API key
