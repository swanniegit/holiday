jQuery(document).ready(function ($) {
  // Custom JavaScript for the widget can go here.

  function limitInput(inputSelector, min, max) {
    const $input = $(inputSelector);

    $input.on("input", function () {
      const value = parseInt($(this).val(), 10);

      // Restrict the value within the min and max range
      if (value > max) {
        $(this).val(max);
      } else if (value < min) {
        $(this).val(min);
      }

      // Ensure the input is a number and remove invalid characters
      if (!Number.isInteger(value)) {
        $(this).val("");
      }
    });
  }

  let getNumberOfNights = (date1, date2) => {
    const departDate = new Date(date1);
    const returnDate = new Date(date2);

    const differenceInMilliseconds = returnDate - departDate;
    const differenceInDays = differenceInMilliseconds / (1000 * 60 * 60 * 24);

    return differenceInDays;
  };

  let formatDate = (dateString) => {
    if (!dateString) return;

    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
      return;
    }

    const formatted = new Intl.DateTimeFormat("en-GB", {
      day: "numeric",
      month: "short",
      year: "2-digit",
    }).format(date);

    return formatted;
  };

  let formatCurrency = (amount) => {
    const number = parseFloat(amount);
    const formatted = new Intl.NumberFormat("en-ZA", {
      style: "currency",
      currency: "ZAR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(number);

    return formatted.replace("ZAR", "R"); // Replace currency code with "R" if needed
  };

  $("#nbrChildren").on("change", function () {
    const numChildren = Math.min(parseInt($(this).val()) || 0, 4);
    const $numChildrenContainer = $("#numChildren");

    // Clear previous child inputs
    $numChildrenContainer
      .find(".child-age-input, input[name^='childAge'], .errorMessages")
      .remove();

    // Add new child inputs
    for (let i = 1; i <= numChildren; i++) {
      $numChildrenContainer.append(`
            <label class="child-age-input" id="childInput${i}" for="childAge${i}">Child Age ${i}</label>
            <input type="number" name="childAge${i}" id="childAge${i}" min="2" max="17" value="0" maxlength="2">
            <p class="errorMessages" id="childrenAgeError${i}"></p>
        `);
    }
  });

  // Limit children input to 0–4
  limitInput("#nbrChildren", 0, 4);

  // Limit adults input to 1–6
  limitInput("#nbrAdults", 1, 6);

  // Limit infants input to 0–2
  limitInput("#nbrInfants", 0, 2);

  $("#nbrInfants").on("input", function () {
    const numInfants = parseInt($(this).val()) || 0;

    const $numInfantsContainer = $("#numInfants");
    $numInfantsContainer.find("hr").nextAll().remove();

    const today = new Date();
    const maxDate = today.toISOString().split("T")[0];
    const minDate = new Date(today.setFullYear(today.getFullYear() - 2))
      .toISOString()
      .split("T")[0];

    for (let i = 1; i <= numInfants; i++) {
      $numInfantsContainer.append(`
      <label for="infantDOB${i}">Infant DOB ${i}:</label>
      <input 
        type="date" 
        name="infantDOB${i}" 
        id="infantDOB${i}" 
        min="${minDate}" 
        max="${maxDate}" 
        value="">
    `);
    }
  });

  $(document).on("click", "#openModal", function () {
    let dateDeparture = new Date($("#dateDeparture").val() + "T00:00:00Z");
    let dateReturn = new Date($("#dateReturn").val() + "T00:00:00Z");
    let differenceInDays = getNumberOfNights(dateDeparture, dateReturn);

    const roomId = $(this).data("room-id");
    const hotelName = $(this).data("hotel-name");
    const accSpecial1 = $(this).data("accspecial1") || "";
    const honeymoonRate = $(this).data("honeymoon-rate");
    const roomPackages = $(this)
      .data("room-packages")
      .split(",")
      .map((pkg) => {
        const [packageDesc, packagePriceZARFrom, pricePerPersonZARFrom] =
          pkg.split("|");
        return {
          packageDesc,
          packagePriceZARFrom,
          pricePerPersonZARFrom,
        };
      });

    $("#packageOptions").empty();

    $("#packageOptions").append(
      $("<option>", {
        value: "",
        text: "-- Select Package --",
      })
    );

    roomPackages.forEach((package) => {
      $("#packageOptions").append(
        $("<option>", {
          value: package.packageDesc,
          text: `${roomId} ${package.packageDesc}`,
        })
      );
    });

    $("#bcb-modalContent h2").text(roomId);

    $("#depDest").val($("#departureCity").val());
    $("#roomName").val(roomId);
    $("#hotelName").val(hotelName);
    $("#accSpecial1").val(accSpecial1);
    $("#honeymoonRate").val(honeymoonRate);
    $("#noAdults").val($("#nbrAdults").val());
    $("#travelDate").val($("#dateDeparture").val());
    $("#noChildren").val($("#nbrChildren").val());
    $("#noInfants").val($("#nbrInfants").val());
    $("#stayLength").val(differenceInDays);

    // Show the modal
    $("#id01").show();
  });

  $(document).on("click", "#closeModal", function () {
    $("#id01").hide();
  });

  // Open Quote Modal
  $(document).on("click", ".openQuoteModal", function () {
    const button = $(this);

    // Store reference to this specific button on the form
    $("#beachcomber_quote-form").data("source-button", button);

    const quoteRef = $(this).data("hotel-quoteref") || "";
    const roomQuoteRef = $(this).data("quoteref-list") || "";
    const transferRef = $(this).data("transfer-ref") || "";
    const gdsRef = $(this).data("gds-ref") || "";

    // Fill hidden inputs
    $("#quoteRequestObjRef").val(quoteRef);
    // If you want to send a list of room quotes, join them by commas; here just one room quote
    $("#quoteRefList").val(roomQuoteRef);
    $("#transferProductRef").val(transferRef);
    $("#gdsRequestReference").val(gdsRef);

    button
      .removeClass("showing-message")
      .addClass("btn-secondary")
      .prop("disabled", false);

    // Hide message and show button text
    button.find(".success-message").hide();
    button.find(".button-text").show();

    // Show modal
    $("#quoteModal").show();
  });

  // Close Quote Modal
  $(document).on("click", "#closeQuoteModal", function () {
    $("#quoteModal").hide();
    $("#quote-form-response").hide();
  });

  $("input[name='includeAir']").on("change", function () {
    if (!$(this).is(":checked")) {
      $(".flight-options").hide();
      $(".flight-tab").hide();
      $("#depDestRow").hide();

      $("#departureCity").attr("disabled", true);

      $("#submitForm").css({
        bottom: "0px",
      });
    } else {
      $(".flight-tab").show();
      $(".flight-options").show();
      $("#depDestRow").show();

      $("#departureCity").attr("disabled", false);
    }
  });
  $("input[name='weddingRates']").on("change", function () {
    if (!$(this).is(":checked")) {
      $(".honeymoon-toggle").show();
    } else {
      $(".honeymoon-toggle").hide();
    }
  });
  $("input[name='honeymoonRates']").on("change", function () {
    if (!$(this).is(":checked")) {
      $(".wedding-toggle").show();
    } else {
      $(".wedding-toggle").hide();
    }
  });
  $("input[name='dateDeparture']").on("change", function () {
    const departureDate = $(this).val();
    const urlDeparture = urlParams.get("dd");

    if (!departureDate && !urlDeparture) {
      $(".date-return").hide();
      $("#dateReturn").val("");
      $("#dateReturn").removeAttr("min");
      $("#returnError").hide();
    } else {
      $(".date-return").show();
      $("#dateReturn").attr("min", departureDate || urlDeparture);
    }
  });

  $("select[name='flightAdvanced']").on("change", function () {
    if ($(this).val() !== "All Airlines") {
      $(".flight-advanced-info").show();
    } else {
      $(".flight-advanced-info").hide();
    }
  });

  $("input[name='repeaterRates']").on("change", function () {
    if ($(this).is(":checked")) {
      $(".repeat-client-info").show();
    } else {
      $(".repeat-client-info").hide();
    }
  });

  const updateWeddingDateVisibility = () => {
    // Check if either honeymoonRates or weddingRates is checked
    const shouldShow =
      $("input[name='honeymoonRates']").is(":checked") ||
      $("input[name='weddingRates']").is(":checked");

    $(".wedding-date-input").toggle(shouldShow);

    if (shouldShow) {
      $("#weddingDate").attr("required", true);
    } else {
      $("#weddingDate").removeAttr("required");
    }
  };

  // Attach the visibility logic to the change event and initialize on page load
  $("input[name='honeymoonRates'], input[name='weddingRates']")
    .on("change", updateWeddingDateVisibility)
    .trigger("change");

  const validateForm = () => {
    const errors = [];
    const includeAir = $("input[name='includeAir']").is(":checked");

    // RAW values used for validation
    const rawDeparture = $("#dateDeparture").val();
    const rawReturn = $("#dateReturn").val();
    const weddingDateVal = $("#weddingDate").val();

    // Build submission-ready values (keep wedding default for backend)
    const dateDeparture = rawDeparture ? rawDeparture + "T00:00:00Z" : "";
    const dateReturn = rawReturn ? rawReturn + "T00:00:00Z" : "";
    const weddingDateForSubmit = weddingDateVal
      ? weddingDateVal + "T00:00:00Z"
      : "1901-01-01T00:00:00Z";

    const formData = {
      hotelCode: $("#hotelCode").val(),
      dateDeparture: dateDeparture,
      dateReturn: dateReturn,
      departureCity: $("#departureCity").val(),
      includeAir: includeAir.toString(),
      flightAdvanced: includeAir ? $("#flightAdvanced").val() : "",
      flightCabin: includeAir ? $("#flightCabin").val() : "",
      honeymoonRates: $("input[name='honeymoonRates']")
        .is(":checked")
        .toString(),
      repeaterRates: $("input[name='repeaterRates']").is(":checked").toString(),
      weddingRates: $("input[name='weddingRates']").is(":checked").toString(),
      weddingDate: weddingDateForSubmit, // submission-ready (defaulted to 1901 if empty)
      nbrAdults: parseInt($("#nbrAdults").val()) || 0,
      nbrChildren: parseInt($("#nbrChildren").val()) || 0,
      nbrInfants: parseInt($("#nbrInfants").val()) || 0,
      infantDOB1: $("#infantDOB1").val()
        ? $("#infantDOB1").val() + "T00:00:00Z"
        : "",
      infantDOB2: $("#infantDOB2").val()
        ? $("#infantDOB2").val() + "T00:00:00Z"
        : "",
    };

    // Basic required-field validation (use raw values where appropriate)
    if (!formData.hotelCode) {
      errors.push({
        field: "#hotelCodeError",
        message: "Hotel code is required.",
      });
    }
    if (!formData.departureCity) {
      errors.push({
        field: "#departureCityError",
        message: "Departure city is required.",
      });
    }
    if (!rawDeparture) {
      errors.push({
        field: "#departureError",
        message: "Departure date is required.",
      });
    }
    if ($(".date-return").is(":visible") && !rawReturn && rawDeparture) {
      errors.push({
        field: "#returnError",
        message: "Return date is required.",
      });
    }

    // Honeymoon/wedding mutual selection check (only one allowed)
    if (
      $("input[name='honeymoonRates']").is(":checked") &&
      $("input[name='weddingRates']").is(":checked")
    ) {
      errors.push({
        field: "#honeyMoonErrorMessage",
        message:
          "Only one of Honeymoon and Wedding Anniversary Special Rates may be selected.",
      });
    }

    // Wedding date required if honeymoon OR wedding is selected (validate raw value)
    if (
      ($("input[name='honeymoonRates']").is(":checked") ||
        $("input[name='weddingRates']").is(":checked")) &&
      !weddingDateVal
    ) {
      errors.push({
        field: "#WeddingErrorMessage",
        message: "A valid Wedding Date is required.",
      });
    }

    // Date-range validation (only if both raw dates exist)
    if (rawDeparture && rawReturn) {
      const dep = new Date(dateDeparture);
      const ret = new Date(dateReturn);
      if (isNaN(dep.getTime()) || isNaN(ret.getTime())) {
        // invalid date format
        errors.push({
          field: "#departureError",
          message: "Invalid travel dates.",
        });
      } else {
        const dayDifference = (ret - dep) / (1000 * 60 * 60 * 24);
        if (dayDifference < 3) {
          errors.push({
            field: "#departureError",
            message: "Stay must be at least 3 days.",
          });
        }
        if (dayDifference > 14) {
          errors.push({
            field: "#returnError",
            message: "Stay cannot exceed 14 days.",
          });
        }
      }
    }

    // Validate child ages
    const childAges = {};
    for (let i = 1; i <= formData.nbrChildren; i++) {
      const childAge = parseInt($(`#childAge${i}`).val()) || 0;
      if (childAge < 2 || childAge > 17) {
        errors.push({
          field: "#childrenAgeError",
          message: `Child Age ${i} must be between 2 and 17.`,
        });
      }
      childAges[`childAge${i}`] = childAge;
    }
    Object.assign(formData, childAges);

    const totalPeople =
      formData.nbrAdults + formData.nbrChildren + formData.nbrInfants;
    if (totalPeople > 9) {
      errors.push({
        field: "#numOfPeopleErrorMessage",
        message: "The total number of people cannot exceed 9.",
      });
    }

    return { formData, errors, rawDeparture, rawReturn, weddingDateVal };
  };

  const hideError = (field) => {
    $(field).hide();
  };

  // Attach event listeners to input fields to hide errors when corrected
  $("#hotelCode, #departureCity").on("input change", function () {
    hideError(`#${$(this).attr("id")}Error`);
  });

  $("#dateDeparture, #dateReturn").on("input change", function () {
    const { errors } = validateForm();

    const departureError = errors.find(
      (err) => err.field === "#departureError"
    );
    const returnError = errors.find((err) => err.field === "#returnError");

    if (departureError) {
      $("#departureError").text(departureError.message).show();
    } else {
      $("#departureError").hide();
    }

    if (returnError) {
      $("#returnError").text(returnError.message).show();
    } else {
      $("#returnError").hide();
    }
  });

  $("#nbrChildren").on("input change", function () {
    for (let i = 1; i <= 4; i++) {
      hideError(`#childrenAgeError`);
    }
  });

  $("#nbrAdults, #nbrInfants").on("input change", function () {
    hideError("#numOfPeopleErrorMessage");
  });

  const showErrors = (errors) => {
    $(".errorMessages").hide(); // Clear previous errors
    errors.forEach((error) => {
      $(error.field).text(error.message).show();
    });
  };

  $("#submitWidgetForm").on("click", function (e) {
    e.preventDefault();

    let hc = $("#beachcomber_booking-searchWidget #hotelCode").val();
    let a = $(
      "#beachcomber_booking-searchWidget #beachcomber_booking-guests"
    ).val();
    let dd = $("#beachcomber_booking-searchWidget #dateDeparture").val();
    let dr = $("#beachcomber_booking-searchWidget #dateReturn").val();

    // redirect to booking results page
    window.location.href =
      "/beachcomber-search-results/?hc=" +
      encodeURIComponent(hc) +
      "&a=" +
      encodeURIComponent(a) +
      "&dd=" +
      encodeURIComponent(dd) +
      "&dr=" +
      encodeURIComponent(dr);
    return false;
  });

  if (window.location.pathname.includes("beachcomber-search-results")) {
    // Check for URL parameters
    var urlParams = new URLSearchParams(window.location.search);
    if (
      urlParams.has("hc") &&
      urlParams.has("a") &&
      urlParams.has("dd") &&
      urlParams.has("dr")
    ) {
      // Populate form fields
      $("#hotelCode").val(urlParams.get("hc"));
      $("#nbrAdults").val(urlParams.get("a"));
      $("#dateDeparture").val(urlParams.get("dd"));
      $("#dateReturn").val(urlParams.get("dr"));

      $(".date-return").show();
      $("#dateReturn").attr("min", urlParams.get("dd"));

      window.history.replaceState({}, document.title, window.location.pathname);

      // Trigger form submit
      handleSubmitForm({
        preventDefault: () => {},
        currentTarget: $("#submitForm"),
      });
    }

    // $("#booking-form-wrapper").slideUp();
    // $("#toggle-booking-form").show();

    const widget = document.getElementById(
      "beachcomber_booking-floating-widget"
    );
    if (widget) {
      widget.style.display = "none";
    }
  }

  function handleSubmitForm(e) {
    e.preventDefault();

    $("#apiErrorContainer").empty().hide();

    const submitButton = $(e.currentTarget);
    submitButton
      .prop("disabled", true)
      .val("Searching...")
      .addClass("searchButton-loading");

    const { formData, errors } = validateForm();

    if (errors.length > 0) {
      showErrors(errors);
      submitButton
        .prop("disabled", false)
        .val("Search")
        .removeClass("searchButton-loading");
      return;
    }
    $(".skeleton-loader").show();
    $(".booking-results-skeleton-loader").show();
    $(".results-section").hide();

    $.ajax({
      url: beachcomberBookingScript.getbooking_url,
      type: "POST",
      data: JSON.stringify(formData),
      contentType: "application/json",
      success: function (data) {
        const response = data;
        const errorContainer = $("#apiErrorContainer").empty().hide();

        if (response.errorMsg) {
          errorContainer.html(`<p>${response.errorMsg}</p>`).show();
          $(".booking-results-skeleton-loader").hide();
          submitButton
            .prop("disabled", false)
            .val("Search")
            .removeClass("searchButton-loading");
          return;
        }

        if (!response) {
          errorContainer.html("<p>No results found.</p>");
        }

        // FLIGHT SECTION
        const $flightSection = $(".flight-section");
        const $tableBody = $(".flight-info-container");
        const flightTemplate = $("#flight-layout-template").html();
        $tableBody.empty();

        if (!response.airGDS || response.airGDS.length === 0) {
          $flightSection.hide();
        } else {
          $flightSection.show();

          let departingFlights = [],
            returningFlights = [];
          const flights = response.airGDS;

          if (flights.length === 2) {
            departingFlights = [flights[0]];
            returningFlights = [flights[1]];
          } else if (flights.length === 3) {
            departingFlights = [flights[0]];
            returningFlights = [flights[1], flights[2]];
          } else if (flights.length === 4) {
            departingFlights = [flights[0], flights[1]];
            returningFlights = [flights[2], flights[3]];
          } else {
            console.log("Unexpected flight data structure");
          }

          const flightContainer = $("<div class='flight-container'></div>");
          const departingSection = $(
            "<div class='departing-flights'><h2 class='departing-heading'>Departing</h2></div>"
          );
          const returningSection = $(
            "<div class='returning-flights'><h2 class='returning-heading'>Returning</h2></div>"
          );

          const renderFlight = (flightInfo) =>
            flightTemplate
              .replace(/\$\{operatingCarrier\}/g, flightInfo?.operatingCarrier)
              .replace(/\$\{carrierCode\}/g, flightInfo?.flightRefNr)
              .replace(/\$\{cabin\}/g, flightInfo?.cabin)
              .replace(/\$\{fromArptCode\}/g, flightInfo?.fromArpt)
              .replace(/\$\{toArptCode\}/g, flightInfo?.toArpt)
              .replace(/\$\{depDate\}/g, formatDate(flightInfo?.depDateTime))
              .replace(
                /\$\{depTime\}/g,
                flightInfo?.depDateTime.split("T")[1].slice(0, 5)
              )
              .replace(/\$\{arrDate\}/g, formatDate(flightInfo?.arrDateTime))
              .replace(
                /\$\{arrTime\}/g,
                flightInfo?.arrDateTime.split("T")[1].slice(0, 5)
              );

          departingFlights.forEach((f) =>
            departingSection.append($(renderFlight(f)))
          );
          returningFlights.forEach((f) =>
            returningSection.append($(renderFlight(f)))
          );

          flightContainer.append(departingSection).append(returningSection);
          $tableBody.append(flightContainer);
        }

        // HOTEL INFO
        $("h3.hotel-name").html(response.hotelName);
        $("p.hotel-description").html(response.hotelDescription);

        // CAROUSEL
        $(".slides").empty();
        $(".carousel-dots").empty();

        const filteredItems = response.hotelImages?.filter(
          (item) => item.dimensions.toLowerCase() === "1280x720"
        );

        filteredItems.forEach((image, index) => {
          const prevIndex =
            (index - 1 + filteredItems.length) % filteredItems.length;
          const nextIndex = (index + 1) % filteredItems.length;

          $(".slides").append(`
          <input type="radio" name="radio-buttons" id="img-${index}" ${
            index === 0 ? "checked" : ""
          } />
          <li class="slide-container">
            <div class="slide-image">
              <img src="${image.imageURL}">
            </div>
            <div class="carousel-controls">
              <label for="img-${prevIndex}" class="prev-slide"><span>&lsaquo;</span></label>
              <label for="img-${nextIndex}" class="next-slide"><span>&rsaquo;</span></label>
            </div>
          </li>
        `);

          $(".carousel-dots").append(
            `<label for="img-${index}" class="carousel-dot" id="dot-${index}"></label>`
          );
        });

        // ROOMS
        if (response.roomOptions) {
          $(".room-options").html("");

          const quoteRefList = response.roomOptions
            .map((room) => room.sendQuoteReferences)
            .join(", ");
          response.roomOptions.forEach((room, i) => {
            const firstImage = room.productImages?.[0]?.imageURL;

            $(".room-options").append(`
            <div id="room-${i}" class="bcp-rooms flex-container">
              <div class="room-info">
                <h2>${room.accomProductName}</h2>
                <p>${room.accomProdDescription}</p>
                <img src="${firstImage}" alt="Room image" />
              </div>
              <div class="room-images">
                <p>Check-in: ${formatDate(response.travelFromDate)}</p>
                <p>Check-out: ${formatDate(response.travelToDate)}</p>
                <p class="room-allocation">Room Allocation: ${
                  room.roomAllocation
                }</p>
                <p class="room-status">Room Availability Status: ${
                  room.roomStatus
                }</p>
                <p class="pax">Person/s quoted: ${room.totalPax}</p>
                ${
                  room.accSpecial1
                    ? `<p class="rooms-accSpecial1">Special Offers: <span class="rooms-specialOffer">${room.accSpecial1}</span></p>`
                    : ""
                }
                ${
                  room.importantNotes
                    ? `<p class="rooms-importantNotes">Important Notes: ${room.importantNotes}</p>`
                    : ""
                }
                <p class="package-from">${
                  room.numberOfNights
                }-night package from:</p>
                <ul class="room-packages">
                  ${room.packages
                    .map(
                      (pkg) =>
                        `<li>Total package:&nbsp;&nbsp;&nbsp;${formatCurrency(
                          pkg.packagePriceZARFrom
                        )} (${pkg.packageDesc})</li>`
                    )
                    .join("")}
                </ul>
                <button
                  class="btn btn-primary"
                  id="openModal"
                  data-room-id="${room.accomProductName}"
                  data-hotel-name="${response.hotelName}"
                  data-honeymoon-rate="${response.honeymoonRates}"
                  data-accSpecial1="${room.accSpecial1}"
                  data-room-packages="${room.packages
                    .map(
                      (pkg) =>
                        `${pkg.packageDesc}|${pkg.packagePriceZARFrom}|${pkg.pricePerPersonZARFrom}`
                    )
                    .join(",")}"
                >Enquire Now</button>

              <button
              class="btn btn-secondary openQuoteModal"
              data-room-id="${room.accomProductName}"
              data-quoteref-list="${quoteRefList}"
              data-hotel-quoteref="${response.quoteRef}"
              data-transfer-ref="${response.transferProductRef}"
              data-gds-ref="${response.airGDS?.[0]?.requestReference ?? ""}"
            >
            <span class="button-text">Email Quote</span>
            <span class="success-message" style="display:none;"></span>
            </button>
              </div>
            </div>
          `);
          });
        }

        // INCLUSIONS
        if (response.inclusions) {
          $(".inclusions-section").html("<h2>Inclusions</h2>");
          response.inclusions.forEach((text, i) =>
            $(".inclusions-section").append(
              `<p id="inclusions-info-${i}">${text}</p>`
            )
          );
        }

        // Final UI state
        submitButton
          .prop("disabled", false)
          .val("Search")
          .removeClass("searchButton-loading");
        $(".booking-results-skeleton-loader").hide();
        $(".results-section").show();

        // hide form once results are shown
        $("#booking-form-wrapper").slideUp();
        $("#toggle-booking-form").text("Show Search").show();
      },

      error: function (jqXHR, textStatus, errorThrown) {
        console.error("Error:", textStatus, errorThrown);
        $(".loading-spinner").hide();
      },
    });
  }

  $("#submitForm").on("click", handleSubmitForm);

  $("#toggle-booking-form").on("click", function () {
    const $form = $("#booking-form-wrapper");
    const $btn = $(this);

    const isVisible = $form.is(":visible"); // Check current state BEFORE toggling

    if (isVisible) {
      $btn.text("Show Search");
    } else {
      $btn.text("Hide Search");
      // Scroll only if it's about to become visible
      $("html, body").animate({ scrollTop: $form.offset().top }, 500);
    }

    $form.slideToggle(300);
  });

  $("#beachcomber_quote-form").on("submit", function (e) {
    e.preventDefault();

    const form = $(this);

    const submitQuoteBtn = form.find(
      "button[type='submit'].submitQuoteButtonLoader"
    );

    submitQuoteBtn.addClass("loading").prop("disabled", true);

    const data = {
      quoteRequestObjRef: $("#quoteRequestObjRef").val(),
      quoteRefList: $("#quoteRefList").val(),
      gdsRequestReference: $("#gdsRequestReference").val(),
      transferProductRef: $("#transferProductRef").val(),
      clientReference: $("#clientReference").val() || "",
      firstname: $("#firstname").val(),
      surname: $("#surname").val(),
      emailAddress: $("#emailAddress").val(),
      mobilePhone: $("#mobilePhone").val(),
    };

    const originalButton = $(
      `.openQuoteModal[data-quoteref-list='${data.quoteRefList}']`
    );

    $.ajax({
      url: beachcomberBookingScript.sendQuote_url,
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify(data),
      success: function (response) {
        $("#quoteModal").hide();
        const quoteNumber = response.quoteNumber;

        if (originalButton.length > 0) {
          originalButton.find(".button-text").hide();
          originalButton
            .find(".success-message")
            .html(`${quoteNumber} has been successfully emailed`)
            .removeClass("error")
            .show();

          originalButton
            .prop("disabled", true)
            .removeClass("btn-secondary")
            .addClass("showing-message");
        }

        form[0].reset();

        submitQuoteBtn.removeClass("loading").prop("disabled", false);
      },
      error: function (xhr) {
        let errMsg = "Failed to send quote request.";
        if (xhr.responseJSON && xhr.responseJSON.message) {
          errMsg = xhr.responseJSON.message;
        }

        if (originalButton.length > 0) {
          originalButton.find(".button-text").hide();
          originalButton
            .find(".success-message")
            .html("Error: " + errMsg)
            .addClass("error")
            .show();

          originalButton
            .prop("disabled", true)
            .removeClass("btn-secondary")
            .addClass("showing-message");
        }

        submitQuoteBtn.removeClass("loading").prop("disabled", false);
      },
    });
  });

  let cachedRates = [];

  async function fetch_rates_data() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const sid = urlParams.get("special_id");
    const $container = $("#holiday_special_container");

    const hotelFilterValue = urlParams.get("hotel");
    const specialFilterValue = urlParams.get("special");

    if (hotelFilterValue) {
      $("#filter-hotel").val(hotelFilterValue);
    }

    if (specialFilterValue) {
      $("#filter-special").val(specialFilterValue);
    }

    if (!sid) {
      const skeleton = `
      <div class="holiday-skeleton-container">
        ${[1, 2, 3]
          .map(
            () => `
          <div class="holiday-skeleton-card">
            <div class="holiday-skeleton-image"></div>
            <div class="holiday-skeleton-box w70"></div>
            <div class="holiday-skeleton-box w50"></div>
            <div class="holiday-skeleton-box w30"></div>
          </div>
        `
          )
          .join("")}
      </div>
    `;

      $container.html(skeleton);
      try {
        $.get(beachcomberBookingScript.getrates_url, function (response) {
          const $tableBody = $("#holiday_specials_container");
          const template = $("#specials-data").html();

          if (!template) {
            console.error("Template not found");
            return;
          }

          $tableBody.empty(); // Clear existing rows

          cachedRates = response.beachcomberRates; // Save for filtering

          populateFilterOptions();
          applyFiltersFromURL();
          renderFilteredRates();
        }).fail(function (jqXHR, textStatus, errorThrown) {
          console.error("AJAX Error:", textStatus, errorThrown);
          $("#holiday_specials_container").html(
            "<p>Error loading data. Please try again later.</p>"
          );
        });
      } catch (error) {
        console.error("Unexpected Error:", error);
        $("#holiday_specials_container").html(
          "<p>Error loading data. Please try again later.</p>"
        );
      }
    }
  }

  function populateFilterOptions() {
    const hotelSet = new Set();
    const specialSet = new Set();

    cachedRates.forEach((rate) => {
      if (rate.hotelName) hotelSet.add(rate.hotelName);
      if (rate.accSpecial1) specialSet.add(rate.accSpecial1);
    });

    const $hotelFilter = $("#filter-hotel");
    const $specialFilter = $("#filter-special");

    $hotelFilter.empty().append(`<option value="">All Hotels</option>`);
    $specialFilter.empty().append(`<option value="">All Specials</option>`);
    $specialFilter.append(
      `<option value="excludes_honeymoon_offers">All Specials Except Honeymoon</option>`
    );

    Array.from(hotelSet)
      .sort()
      .forEach((hotel) =>
        $hotelFilter.append(`<option value="${hotel}">${hotel}</option>`)
      );

    Array.from(specialSet)
      .sort()
      .forEach((special) =>
        $specialFilter.append(`<option value="${special}">${special}</option>`)
      );

    updateResetButtonVisibility();
  }

  function applyFiltersFromURL() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);

    const hotelFilterValue = urlParams.get("hotel");
    const specialFilterValue = urlParams.get("special");

    // Apply the filter values from the URL to the dropdowns
    if (hotelFilterValue) {
      $("#filter-hotel").val(hotelFilterValue);
    }

    if (specialFilterValue) {
      $("#filter-special").val(specialFilterValue);
    }

    // Trigger the filtering after applying URL parameters
    renderFilteredRates();
  }

  function renderFilteredRates() {
    const $tableBody = $("#holiday_specials_container");
    const template = $("#specials-data").html();
    const selectedHotel = $("#filter-hotel").val();
    const selectedSpecial = $("#filter-special").val();

    if (!template) {
      console.error("Template not found");
      return;
    }

    const filteredRates = cachedRates.filter((data) => {
      if (!data?.identity) return false;

      const hotelMatch = !selectedHotel || data.hotelName === selectedHotel;

      let specialMatch = true;
      if (selectedSpecial === "excludes_honeymoon_offers") {
        specialMatch = !/honeymoon/i.test(data.accSpecial1);
      } else if (selectedSpecial) {
        specialMatch = data.accSpecial1 === selectedSpecial;
      }

      return hotelMatch && specialMatch;
    });

    $tableBody.empty();

    if (filteredRates.length === 0) {
      $tableBody.html("<p>No specials found for the selected filters.</p>");
      return;
    }

    filteredRates.forEach((data) => {
      const row = template
        .replace(
          /\$\{specialLink\}/g,
          "./beachcomber-specials/?special_id=" + data.identity
        )
        .replace(/\$\{hotelName\}/g, data.hotelName)
        .replace(/\$\{accSpecial1\}/g, data.accSpecial1)
        .replace(/\$\{numberOfNights\}/g, data.numberOfNights)
        .replace(/\$\{pax\}/g, data.totalPax)
        .replace(/\$\{roomName\}/g, data.accomProductName)
        .replace(
          /\$\{hotelImage\}/g,
          `<img src="${data.hotelImages[0].imageURL}" alt="${data.hotelName}" />`
        )
        .replace(
          /\$\{travelFromDate\}/g,
          formatDate(data.travelFromDate.split("T")[0])
        )
        .replace(
          /\$\{travelToDate\}/g,
          formatDate(data.travelToDate.split("T")[0])
        )
        .replace(
          /\$\{pricePPS\}/g,
          formatCurrency(data.packages[0].pricePerPersonZARFrom)
        )
        .replace(/\$\{transferType\}/g, data.transferType)
        .replace(/\$\{includeAir\}/g, data.includeAir ? "Includes Air" : "")
        .replace(/\$\{departFrom\}/g, data.departFrom);

      $tableBody.append(row);
    });
    // Update URL with the selected filters
    const url = new URL(window.location);
    if (selectedHotel) {
      url.searchParams.set("hotel", selectedHotel);
    } else {
      url.searchParams.delete("hotel");
    }

    if (selectedSpecial) {
      url.searchParams.set("special", selectedSpecial);
    } else {
      url.searchParams.delete("special");
    }

    window.history.pushState({ path: url.href }, "", url.href);
  }

  $("#filter-hotel, #filter-special").on("change", function () {
    renderFilteredRates();
    updateResetButtonVisibility();
  });

  const hotelFilter = document.getElementById("filter-hotel");
  const specialFilter = document.getElementById("filter-special");
  const resetBtn = document.getElementById("reset-filters");

  function updateResetButtonVisibility() {
    if (hotelFilter?.value || specialFilter?.value) {
      resetBtn && (resetBtn.style.display = "inline-block");
    } else {
      resetBtn && (resetBtn.style.display = "none");
    }
  }

  if (hotelFilter) {
    hotelFilter.addEventListener("change", updateResetButtonVisibility);
  }

  if (specialFilter) {
    specialFilter.addEventListener("change", updateResetButtonVisibility);
  }

  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      hotelFilter.value = "";
      specialFilter.value = "";

      renderFilteredRates();
      updateResetButtonVisibility();
    });
  }

  fetch_rates_data();

  async function fetch_rate_data() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const sid = urlParams.get("special_id");

    if (sid) {
      try {
        const $container = $("#holiday_special_container");
        const $skeleton = $("#holiday_special_skeleton");
        $container.hide();
        $skeleton.show();

        const response = await $.get(beachcomberBookingScript.getrates_url);

        var result = response.beachcomberRates.find(
          (obj) => obj.identity === sid
        );

        $skeleton.hide();
        $container.show();

        $container.find("ul").empty();
        $(".carousel-dots").empty();
        $(".slides").empty();
        $("#packageOptions").empty();
        $("#packages").empty();

        $("#hotelName").val(result?.hotelName);
        $("#roomName").val(result?.accomProductName);
        $("#accSpecial1").val(result?.accSpecial1);
        $("#honeymoonRate").val(
          result?.accSpecial1 === "Honeymoon Offer" ? "true" : "false"
        );

        // Update the HTML content with the fetched data
        $("#holiday_special_container h2").text(result?.hotelName);
        $("#holiday_special_container h2 span").text(result?.accomProductName);
        $("#holiday_special_container .accSpecial1").text(result?.accSpecial1);
        // $("#holiday_special_container .accomDesc").text(
        //   result?.accomProdDescription
        // );

        $("#importantNotes").text(result?.importantNotes);

        $(".numberOfNights").text(result?.numberOfNights + " nights");
        $(".pax").text(result?.totalPax);
        $(".roomName").text(result?.accomProductName);
        $(".travelFromDate").text(
          "Travel between " +
            formatDate(result?.travelFromDate) +
            " - " +
            formatDate(result?.travelToDate) || ""
        );
        $(".bookBy").text("Book by " + formatDate(result?.bookingToDate || ""));

        const $inclusionList = $(".packageInclusions ul");
        // Iterate through the data and append list items
        if (result?.packageInclusions.length > 0) {
          result?.packageInclusions.forEach(function (item) {
            $inclusionList.append(`<li>${item.inclusion}</li>`);
          });
        } else {
          $(".packageInclusions").hide();
        }

        const $exclusionsList = $(".packageExclusions ul");
        if (result?.packageExclusions.length > 0) {
          result?.packageExclusions.forEach(function (item) {
            $exclusionsList.append(`<li>${item.exclusion}</li>`);
          });
        } else {
          $(".packageExclusions").hide();
        }

        const $beachcomberPlusFactorsList = $(".plusFactors ul");
        if (result?.beachcomberPlusFactors.length > 0) {
          result?.beachcomberPlusFactors.forEach(function (item) {
            $beachcomberPlusFactorsList.append(`<li>${item.plusFactor}</li>`);
          });
        } else {
          $(".termsAndConditions").hide();
        }

        const $termsAndConditionsList = $(".termsAndConditions ul");
        if (result?.termsAndConditions.length > 0) {
          result?.termsAndConditions.forEach(function (item) {
            $termsAndConditionsList.append(`<li>${item.tCItem}</li>`);
          });
        } else {
          $(".termsAndConditions").hide();
        }

        $(".hotelLink").append(
          `<a href="${result?.hotelInfoAddress}" target="_blank">${result?.hotelName}</a>`
        );
        $(".hotelDescription").text(result?.hotelDescription);

        // loop through the images with dimentions of 1280x720 and append them to the gallery
        const filteredItems = result?.hotelImages.filter(
          (item) => item.dimensions.toLowerCase() === "1280x720"
        );

        filteredItems?.forEach((image, index) => {
          const prevIndex =
            (index - 1 + filteredItems.length) % filteredItems.length;
          const nextIndex = (index + 1) % filteredItems.length;

          $(".slides").append(`
              <input type="radio" name="radio-buttons" id="img-${index}" ${
            index === 0 ? "checked" : ""
          } />
              <li class="slide-container">
                <div class="slide-image">
                  <img src="${image.imageURL}">
                </div>
                <div class="carousel-controls">
                  <label for="img-${prevIndex}" class="prev-slide">
                    <span>&lsaquo;</span>
                  </label>
                  <label for="img-${nextIndex}" class="next-slide">
                    <span>&rsaquo;</span>
                  </label>
                </div>
              </li>
            `);

          // Add dot indicator
          $(".carousel-dots").append(`
              <label for="img-${index}" class="carousel-dot" id="dot-${index}"></label>
            `);
        });

        const $package = $("#packages");
        // $package.append(`
        //   <div class="stay">${result?.numberOfNights + " nights"}</div>
        // `);

        const $packagesDiv = $("<div>", { class: "packages" });

        $packagesDiv.append(`
    <img class="pk-room-image" src="${result?.productImages[0]?.imageURL}" />
    <p class="packageRoom">${result?.roomAllocation} | ${
          result?.numberOfNights + " nights"
        } | ${result?.totalPax} </p>
    <p class="accomProdDesc" >${result?.accomProdDescription}</p>
  <div class="stay">Packages include:</div>
  `);
        const $ul = $("<ul>");

        result?.packages.forEach(function (item) {
          $ul.append(`
      <li class="packageDesc">Per person sharing:  From ${formatCurrency(
        item.pricePerPersonZARFrom
      )}
      ${item.packageDesc} </li>
    `);
          $packagesDiv.append($ul);

          $("#packageOptions").append(
            $("<option>", {
              value: item.packageDesc,
              text: item.packageDesc,
            })
          );
        });

        $package.append($packagesDiv);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    }
  }

  fetch_rate_data();

  $("#beachcomberBookingForm").on("submit", function (e) {
    e.preventDefault();

    const submitButton = $(this).find('button[type="submit"]');
    submitButton.prop("disabled", true);

    submitButton.html("Sending...");

    // Hide previous response message
    $("#form-response").hide();

    // Gather form data
    const formData = {
      action: "send_ajax_email",
      firstName: $("#firstName").val(),
      lastName: $("#lastName").val(),
      email: $("#email").val(),
      mobile: $("#mobile").val(),
      noAdults: $("#noAdults").val(),
      travelDate: $("#travelDate").val(),
      noChildren: $("#noChildren").val(),
      noInfants: $("#noInfants").val(),
      childAges: $("#childAges").val(),
      honeymoonRate: $("#honeymoonRate").val(),
      depDest:
        $("input[name='includeAir']").length > 0 &&
        !$("input[name='includeAir']").is(":checked")
          ? " "
          : $("#depDest").val() || " ",
      hotelName: $("#hotelName").val(),
      roomName: $("#roomName").val(),
      packageOptions: $("#packageOptions").val(),
      // accSpecial1: $("#specials").val(),
      accSpecial1: $("#accSpecial1").val(),
      stayLength: $("#stayLength").val(),
      budget: "R" + $("#budget").val(),
      details: $("#details").val(),
      contactPref: $("input[name='contactPref']:checked").val(),
      send_ajax_email_nonce: $(
        '#beachcomberBookingForm input[name="send_ajax_email_nonce"]'
      ).val(),
    };

    console.log("Form Data:", formData);

    // Send AJAX request
    $.post(beachcomberBookingScript.ajax_url, formData, function (response) {
      const responseElement = $("#form-response");
      if (response.success) {
        responseElement
          .text("Email sent successfully!")
          .css("color", "green")
          .show();
      } else {
        responseElement
          .text("Failed to send email. Please try again.")
          .css("color", "red")
          .show();
      }
    }).always(function () {
      // Re-enable the submit button after the request is complete
      submitButton.prop("disabled", false);
      submitButton.html("Submit");
    });
  });
});
