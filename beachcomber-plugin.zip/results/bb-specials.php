<?php
/*****************************************
* Register a shortcode to display results.
******************************************/

function beachcomber_holiday_specials_page() {

  ob_start();
?>

<div class="beachcomber-booking-wrapper">

<?php
  if (isset($_GET['special_id'])) {
    $special_id = $_GET['special_id']
?>


<!-- Skeleton for the main special container -->
<!-- Skeleton -->
<div id="holiday_special_skeleton" class="skeleton-container" style="display: none;">
  <div class="skeleton-header">
    <div class="skeleton-line title"></div>
    <div class="skeleton-line subtitle"></div>
  </div>

  <div class="skeleton-section">
    <div class="skeleton-line short"></div>
    <div class="skeleton-line"></div>
    <div class="skeleton-line"></div>
  </div>

  <div class="skeleton-lists">
    <div class="skeleton-list">
      <div class="skeleton-line short"></div>
      <div class="skeleton-line"></div>
      <div class="skeleton-line"></div>
    </div>
    <div class="skeleton-list">
      <div class="skeleton-line short"></div>
      <div class="skeleton-line"></div>
      <div class="skeleton-line"></div>
    </div>
  </div>

  <div class="skeleton-gallery">
    <div class="skeleton-image"></div>
    <div class="skeleton-image"></div>
    <div class="skeleton-image"></div>
  </div>

  <div class="skeleton-packages">
    <div class="skeleton-line short"></div>
    <div class="skeleton-line"></div>
    <div class="skeleton-line"></div>
  </div>

  <div class="skeleton-dropdown">
    <div class="skeleton-line short"></div>
  </div>
</div>


  <div id="holiday_special_container">
    <!-- Specials data will be dynamically inserted here -->
    <h2><span></span></h2>
    <div class="accSpecial1"></div>

    <div>
      <div>
        <span class="numberOfNights"></span> | 
        <span class="pax"></span> |
        <span class="roomName"></span> |
        <span class="travelFromDate"></span> |
        <span class="bookBy"></span>
      </div>

      <p class="accomDesc"></p>

      <div id="importantNotes"></div>

      <div class="quickNav">
        <a href="#overview">Overview</a>
        <a href="#hotel">Hotel</a>
        <a href="#packages">Packages</a>
        <a href="#plusFactors">Plus Factors</a>
        <a href="#terms">Terms & conditions</a>
        <a href="#enquire">Enquire</a>
      </div>

      <div id="overview" class="packageInclusions">
        <h5>Includes</h5>
        <ul></ul>
      </div>
      <div class="packageExclusions">
        <h5>Excludes</h5>
        <ul></ul>
      </div>

      <div id="hotel">
        <h5>Hotel</h5>

        <div class="hotelLink"></div>
        <p class="hotelDescription"></p>

<div class="carousel">
  <ul class="slides">
  </ul>
  <div class="carousel-dots"></div>
</div>

      <div id="packages">
        <h5>Packages</h5>
      </div>

      <div id="plusFactors" class="plusFactors">
        <h5>Plus Factors</h5>
        <ul></ul>
      </div>

      <div id="terms" class="termsAndConditions">
        <h5>Terms & conditions</h5>
        <ul></ul>
      </div>

      <div id="enquire">
        <h5>Enquire</h5>

        <form id="beachcomberBookingForm">
          <h6>Personal information</h6>
          <div class="form-row">
            <div class="form-cell">
              <label for="firstName">First Name *</label>
              <input type="text" id="firstName" required/>
            </div>
            <div class="form-cell">
              <label for="lastName">Last Name *</label>
              <input type="text" id="lastName" required/>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="email">Email Address *</label>
              <input type="email" id="email" required/>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="mobile">Mobile Number *</label>
              <input type="tel" id="mobile" required/>
            </div>
          </div>

          <h6>Travel Information</h6>
          <div class="form-row">
            <div class="form-cell">
              <label for="noAdults">Number of Adults?</label>
              <input type="number" id="noAdults" min="1" max="6" />
            </div>
            <div class="form-cell">
              <label for="travelDate">Travel Date *</label>
              <input type="date" id="travelDate" required/>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="noChildren">Number of Children?</label>
              <input type="number" id="noChildren" min="0" max="4" />
            </div>
            <div class="form-cell">
              <label for="childAges">Child Ages</label>
              <input type="text" id="childAges" />
            </div>
            <div class="form-cell">
              <label for="noInfant">Number of Infants?</label>
              <input type="number" id="noInfants" min="0" max="4" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="depDest">Where are you departing from?</label>
              <input type="text" id="depDest" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
            <input type="hidden" id="hotelName">
            <input type="hidden" id="roomName">
            <input type="hidden" id="accSpecial1">
            <input type="hidden" id="honeymoonRate">
              <label for="packageOptions">What package are you interested in?</label>
              <select name="package" id="packageOptions">
                <option value="">-- Select Package --</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="stayLength">How long are you going for?</label>
              <input type="number" id="stayLength" min="1" max="14" />
              <span class="text-x-small">stay in nights</span>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="budget">Estimate budget per person?</label>
                <span>R</span>
                <input type="number" id="budget" min="1000" max="100000" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="details">Please, tell us anything more about this trip that is important to you?</label>
              <textarea id="details" name="details"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <p>How should we contact you for this enquiry?</p>
              <input type="radio" id="prefPhone" name="contactPref" value="phone" /> <label for="prefPhone">Phone</label>
              <input type="radio" id="prefEmail" name="contactPref" value="email" /> <label for="prefEmail">Email</label>
              <input type="radio" id="prefBoth" name="contactPref" value="both" /> <label for="prefBoth">Both</label>
            </div>
          </div>

          <div class="form-row">
            <div class="form-cell">
              <p id="form-response" style="display:none;"></p>

              <?php wp_nonce_field('send_ajax_email_action', 'send_ajax_email_nonce'); ?>
              <button type="submit">Submit</button>
            </div>
          </div>
        </form>
      </div>

    </div>
  </div>
<?php
  } else {
?>
<script type="text/html" id="specials-data">
  <div class="holiday-special-item">
    <a href="${specialLink}">
      <div class="holiday-special-image">
        ${hotelImage}
      </div>
      </a>
      <div class="hotel-info">
        <h5 class="hotelName">${hotelName}</h5>
        <div class="accSpecial1">${accSpecial1}</div>
        <div class="text-price">
          <span> From</span> ${pricePPS} <sup>pps</sup>
        </div>
        <div class="stay">${pax} for ${numberOfNights} nights</div>
        <div class="travelDate">Travel dates: ${travelFromDate} - ${travelToDate}</div>
      </div>

      <div class="view-more">
        <a href="${specialLink}" class="view-more-btn">View Packages</a>
      </div>
  </div>
</script>

<div id="filters" class="beachcomber-filter-section">
  <select id="filter-hotel" class="beachcomber-dropdown">
    <option value="">All Hotels</option>
  </select>

  <select id="filter-special" class="beachcomber-dropdown">
    <option value="">All Specials</option>
  </select>
  
  <button id="reset-filters" class="beachcomber-reset-button" style="display: none;">Reset</button>
</div>

<div id="holiday_specials_container">

</div>


<?php } ?>

</div>

<?php
  return ob_get_clean();
}
add_shortcode('beachcomber_holiday_specials', 'beachcomber_holiday_specials_page');
// Create a WordPress page with [beachcomber_holiday_specials] shortcode to display results.
