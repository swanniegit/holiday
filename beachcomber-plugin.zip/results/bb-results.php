<?php
/*****************************************
* Register a shortcode to display results.
******************************************/

function beachcomber_booking_results_page() {

  $minDay = new DateTime();
  $minDay->modify('+7 day');

  $maxDay = new DateTime();
  $maxDay->modify('+350 day');

  $tomorrow = new DateTime();
  $tomorrow->modify('+7 day');

  $nextday = new DateTime();
  $nextday->modify('+10 day');

  $maxDate = date('Y-m-d');
  $minDate = date('Y-m-d', strtotime('-2 years'));

  ob_start();
?>
<div class="beachcomber-booking-wrapper">
<script type="text/template" id="specials-data">
    <!-- Your template content here -->
</script>

<script type="text/html" id="flight-layout-template">
  <div class="flight">
    <h4>${operatingCarrier}</h4>
    <h4>${carrierCode} – ${cabin}</h4>
    <table>
      <tr>
        <th>${fromArptCode}</th>
        <th>${toArptCode}</th>
      </tr>
      <tr>
        <td>${depDate}</td>
        <td>${arrDate}</td>
      </tr>
      <tr>
        <td>${depTime}</td>
        <td>${arrTime}</td>
      </tr>
    </table>
  </div>
</script>

<div id="booking-form-wrapper">
<form name="searchForm" id="beachcomber_booking-searchForm" method="POST">
  <div>
    <label for="hotelCode">Beachcomber Mauritius:</label>
    <select name="hotelCode" id="hotelCode">
      <option value="">-- Select your hotel --</option>
      <option value="CAN">Canonnier Beachcomber - 4 star</option>
      <option value="MAU">Mauricia Beachcomber - 4 star</option>
      <option value="VIC">Victoria Beachcomber - 4 star superior</option>
      <option value="SHA">Shandrani Beachcomber - 4 star superior</option>
      <option value="TAB">Trou aux Biches Beachcomber - 5 star</option>
      <option value="PAR">Paradis Beachcomber - 5 star</option>
      <option value="DIN">Dinarobin Beachcomber - 5 star</option>
      <option value="RP">Royal Beachcomber - 5 star luxury</option>
    </select>

    <p class="errorMessages" id="hotelCodeError">Hotel Code is required</p>

    <label for="dateDeparture">Departure Date:</label>
<input
  type="date"
  name="dateDeparture"
  id="dateDeparture"
  min="<?=$minDay->format('Y-m-d');?>"
/>
<p class="errorMessages" id="departureError">A valid Departure Date is required</p>

<label for="dateReturn" class="date-return" style="display: none;">Return Date:</label>
<input
  class="date-return"
  type="date"
  name="dateReturn"
  id="dateReturn"
  min="<?=$minDay->format('Y-m-d');?>"
  style="display: none;"
/>
<p class="errorMessages" id="returnError">A valid Return Date is required</p>



    <label for="departureCity">Departure City:</label>
    <select name="departureCity" id="departureCity">
      <option value="CAPE TOWN">Cape Town</option>
      <option value="DURBAN">Durban</option>
      <!--<option value="EAST LONDON">East London</option>-->
      <option value="JOHANNESBURG" selected="selected">Johannesburg</option>
    </select>
    <p class="errorMessages" id="departureCityError">A Departure city is required.</p>


  </div>

 

  <div>


<legend for="includeAir">Include Air:</legend>
<label class="switch">
  <input type="checkbox" name="includeAir" id="includeAir" checked>
  <span class="toggle-slider round"></span>
</label>

<div class="flight-options">
    <label for="flightAdvanced"> Flight Advanced Search:</label>
    <select name="flightAdvanced" id="flightAdvanced">
      <option value="All Airlines" selected="selected">All Airlines</option>
      <option value="SAA Only">SAA Only</option>
      <option value="MK Only">MK Only</option>
    </select>

    <div class="info-box flight-advanced-info">
    <span class="info-icon">i</span>
      <span>The advanced flight search option may not be the cheapest.</span>
    </div>

    <label for="flightCabin">Cabin:</label>
    <select name="flightCabin" id="flightCabin">
      <option value="Cheapest" selected="selected">Cheapest</option>
      <option value="Economy">Economy</option>
      <option value="Business">Business</option>
    </select>

</div>

<legend>Repeat Client Offer:</legend>
    <label class="switch">
  <input type="checkbox" name="repeaterRates" id="repeaterRates">
  <span class="toggle-slider round"></span>
</label>

<div class="info-box repeat-client-info">
      <span>Clients who return within 18 months, or from their 5th visit, enjoy an additional 5% Repeat Client Offer.</span>
    </div>

<div class="honeymoon-toggle">
  <legend>Honeymoon Offer:</legend>
  <label class="switch">
  <input type="checkbox" name="honeymoonRates" id="honeymoonRates">
  <span class="toggle-slider round"></span>
</label>
</div>

<div class="wedding-toggle">
    <legend>Wedding Anniversary Offer:</legend>
    <label class="switch">
  <input type="checkbox" name="weddingRates" id="weddingRates">
  <span class="toggle-slider round"></span>
</label>
</div>

<div class="wedding-date-input">
    <label for="weddingDate">Wedding Date:</label>
    <input type="date" name="weddingDate" id="weddingDate">
<p class="errorMessages" id="WeddingErrorMessage" style="display:none;color:red;"></p>
</div>

    <p class="errorMessages" id="WeddingErrorMessage"></p>
    <p class="errorMessages" id="honeyMoonErrorMessage"></p>
  </div>

  <div>
    <label for="nbrAdults">Number of Adults:</label>
    <input type="number" name="nbrAdults" id="nbrAdults" min="1" max="6" value="2" maxlength="1">
    <div id="numInfants">
    <label for="nbrInfants">Number of Infants:</label>
    <input type="number" name="nbrInfants" id="nbrInfants" min="0" max="2" value="0" maxlength="1">
    </div>

    <p class="errorMessages" id="numOfPeopleErrorMessage"></p>
  </div>


  <div id="numChildren">
    <label for="nbrChildren">Number of Children:</label>
    <input type="number" name="nbrChildren" id="nbrChildren" min="0" max="4" value="0" maxlength="1">
  </div>
  
  <div class="submit-section">
    <input value="Search" type="submit" id="submitForm">
  </div>

</form>
</div>

<div id="apiErrorContainer" class="error-container"></div>

<button id="toggle-booking-form" class="hide-show-search-btn" style="display: none;">
  Show Search
</button>
<!-- <div class="loading-spinner">Loading...</div>-->

<div class="booking-results-skeleton-loader" style="display: none;">
  <div class="booking-skeleton-header"></div>
  <div class="booking-skeleton-text"></div>
  <div class="booking-skeleton-text short"></div>
  <div class="booking-skeleton-image"></div>
</div>


<div class="results-section" style="display: none;">
  <div class="bcp-container travel">

  <div class="navigation">
      <a href="#hotel">Hotel</a>
      <a href="#rooms">Rooms</a>
      <a href="#flights" class="flight-tab">Flights</a>
      <a href="#inclusions">Inclusions</a>
    </div>

    <div class="flight-section" id="flights">
    <div class="flight-info">
      <h2>Flights</h2>
      <div class="flight-info-container">
      </div>
    </div>
  </div> <!-- end flight-section -->



    <div class="hotel-information" id="hotel">
      <h3 class="hotel-name"></h3>
      <p class="hotel-description"></p>
    </div>
  </div> <!-- end travel -->

<!-- Carousel -->
<div class="carousel">
  <ul class="slides">
  </ul>
  <div class="carousel-dots"></div>
</div>

  <div class="room-options" id="rooms">
  </div> <!-- end room-options -->


  
  <div class="inclusions-section" id="inclusions">
  <h2>inclusions</h2>
  </div>



  
  <div id="id01" class="bcb-modal" style="display: none;">
  <div class="bcb-modal-content">
    <div class="bcb-modal-container">
      <span id="closeModal" class="bcb-modal-button bcb-display-topright">&times;</span>
      <div id="bcb-modalContent">
        <!-- Dynamic content will appear here -->
        <h2></h2>
        <form id="beachcomberBookingForm">
          <h6>Personal information</h6>
          <div class="form-row">
            <div class="form-cell">
              <label for="firstName">First Name *</label>
              <input type="text" id="firstName" required />
            </div>
            <div class="form-cell">
              <label for="lastName">Last Name *</label>
              <input type="text" id="lastName" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="email">Email Address *</label>
              <input type="email" id="email" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="mobile">Mobile Number *</label>
              <input type="tel" id="mobile" required />
            </div>
          </div>

          <h6>Travel Information</h6>
          <div class="form-row">
            <div class="form-cell">
              <label for="noAdults">Number of Adults?</label>
              <input type="number" id="noAdults" min="1" max="6" />
            </div>
            <div class="form-cell">
              <label for="travelDate">Travel Date *</label>
              <input type="date" id="travelDate" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="noChildren">Number of Children?</label>
              <input type="number" id="noChildren" min="0" max="4" />
            </div>
            <div class="form-cell">
              <label for="childAges">Child Ages</label>
              <input type="text" id="childAges" />
            </div>
            <div class="form-cell">
              <label for="noInfants">Number of Infants?</label>
              <input type="number" id="noInfants" min="0" max="4" />
            </div>
          </div>
          <div class="form-row" id="depDestRow">
            <div class="form-cell">
              <label for="depDest">Where are you departing from?</label>
              <input type="text" id="depDest" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <input type="hidden" id="hotelName">
              <input type="hidden" id="roomName">
              <input type="hidden" id="accSpecial1">
              <input type="hidden" id="honeymoonRate">
              <label for="packageOptions">What package are you interested in?</label>
              <select name="package" id="packageOptions">
                <option value="">-- Select Package --</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="stayLength">How long are you going for?</label>
              <input type="number" id="stayLength" min="1" max="14" />
              <span class="text-x-small">stay in nights</span>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="budget">Estimate budget per person?</label>
              <span>R</span>
              <input type="number" id="budget" min="1000" max="100000" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="details">Please, tell us anything more about this trip that is important to you?</label>
              <textarea id="details" name="details"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <p>How should we contact you for this enquiry?</p>
              <input type="radio" id="prefPhone" name="contactPref" value="phone" /> <label for="prefPhone">Phone</label>
              <input type="radio" id="prefEmail" name="contactPref" value="email" /> <label for="prefEmail">Email</label>
              <input type="radio" id="prefBoth" name="contactPref" value="both" /> <label for="prefBoth">Both</label>
            </div>
          </div>

          <div class="form-row">
            <div class="form-cell">
              <p id="form-response" style="display:none;"></p>

              <?php wp_nonce_field('send_ajax_email_action', 'send_ajax_email_nonce'); ?>
              <button type="submit">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Quote Modal -->
<div id="quoteModal" class="bcb-modal" style="display: none;">
  <div class="bcb-modal-content">
    <div class="bcb-modal-container">
      <span id="closeQuoteModal" class="bcb-modal-button bcb-display-topright">&times;</span>
      <div id="quote-modalContent">
        <h2>Email Quote</h2>
        <form id="beachcomber_quote-form">
          <h6>Your Details</h6>
          <div class="form-row">
            <div class="form-cell">
              <label for="firstname">First Name *</label>
              <input type="text" id="firstname" required />
            </div>
            <div class="form-cell">
              <label for="surname">Surname *</label>
              <input type="text" id="surname" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="emailAddress">Email Address *</label>
              <input type="email" id="emailAddress" required />
            </div>
            <div class="form-cell">
              <label for="mobilePhone">Mobile Phone *</label>
              <input type="tel" id="mobilePhone" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-cell">
              <label for="clientReference">Reference (optional)</label>
              <input type="text" id="clientReference" />
            </div>
          </div>

    <input type="hidden" id="quoteRequestObjRef" name="quoteRequestObjRef" />
    <input type="hidden" id="quoteRefList" name="quoteRefList" />
    <input type="hidden" id="gdsRequestReference" name="gdsRequestReference" />
    <input type="hidden" id="transferProductRef" name="transferProductRef" />

          <div class="form-row">
            <div class="form-cell">
              <p id="quote-form-response" style="display:none;"></p>
              
              <button type="submit" class="submitQuoteButtonLoader">Email Quote</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>


</div>
</div>
<?php
return ob_get_clean();
}
add_shortcode('beachcomber_search_results', 'beachcomber_booking_results_page');
// Create a WordPress page with [beachcomber_booking_results] shortcode to display results.
